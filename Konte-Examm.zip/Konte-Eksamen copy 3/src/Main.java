import java.io.File;
import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.util.Scanner;


public class Main {
    static IDataBaseHandler dbHandler = new Databasehandler();
    public static void main(String[] args) {

        try {

            File file = new File("src/samlerkort.txt");
            if (!file.exists()) {
                System.out.println("File not found!");
                return;
            }

            System.out.println("File found, starting to read...");

            Scanner scanner = new Scanner(file);
            String section = "";

// Leser linje for linje fra filen
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();
                System.out.println("Reading line: " + line);

// Sjekker hvilke seksjon vi er i basert på filens format
                if (line.equals("Samlerkortserier:")) {
                    section = "Serie";
                    scanner.nextLine(); // Hopp over antall-linjen
                } else if (line.equals("Kort:")) {
                    section = "Kort";
                    scanner.nextLine();
                } else if (line.equals("-------")) {
                    // Hoppe over skillelinjer
                } else {
                    //Prosesserer linjer på seksjonen vi er i
                    switch (section) {
                    case "Serie":
                        System.out.println("Processing series section...");
                        processSerie(line, scanner);
                        break;
                        case "Kort":
                            System.out.println("Processing card section...");
                            processKort(line, scanner);
                            break;
                    }
                }

            }

            System.out.println("Finished reading file");
            scanner.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

// Metode for å prosessere serier
    private static void processSerie(String firstline, Scanner scanner) {
        int id = Integer.parseInt(firstline);
        String utgiver = scanner.nextLine().trim();
        int utgitt = Integer.parseInt(scanner.nextLine().trim());
        String sport = scanner.nextLine().trim();
        int antall = Integer.parseInt(scanner.nextLine().trim());
        System.out.println("Parsed Serie: " + id + ", " + utgiver + ", " + utgitt + ", " + sport + ", " + antall);
        dbHandler.insertSamlerkortSerie(id, utgiver, utgitt, sport, antall);
    }

// Metode for å prosessere kort
    private static void processKort(String firstline, Scanner scanner) throws SQLException {
        int id = Integer.parseInt(firstline);
        int serie = Integer.parseInt(scanner.nextLine().trim());
        String tilstand = scanner.nextLine().trim();
        String spillernavn = scanner.nextLine().trim();
        String klubb = scanner.nextLine().trim();
        int sesonger = Integer.parseInt(scanner.nextLine().trim());
        int kamper = Integer.parseInt(scanner.nextLine().trim());
        String sport = scanner.nextLine().trim();

        // Sjekk sportstype og setter inn data i riktig tabell
        switch (sport.toLowerCase()) {
            case "fotball":
                int seriescoringer = Integer.parseInt(scanner.nextLine().trim());
                int cupscoringer = Integer.parseInt(scanner.nextLine().trim());
                System.out.println("Parsed Fotballkort: " + id + ", " + serie + ", " + tilstand + ", " + spillernavn + ". " + klubb + ", " + sesonger + ", " + kamper + ", " + seriescoringer + ", " + cupscoringer);
                double poengsnitt = 0;
                dbHandler.insertFotballkort(id, serie, tilstand, spillernavn, klubb, sesonger, kamper, seriescoringer, cupscoringer);
                break;
            case "basketball":
                int fgPercent = Integer.parseInt(scanner.nextLine().trim());
                int ftPercent = Integer.parseInt(scanner.nextLine().trim());
                poengsnitt = Double.parseDouble(scanner.nextLine().trim());
                System.out.println("Parsed Basketballkort: " + id + ", " + serie + ", " + tilstand + ", " + spillernavn + ". " + klubb + ", " + sesonger + ", " + kamper + ", " + fgPercent + ", " + ftPercent + ", " + poengsnitt);
                dbHandler.insertBasketballkort(id, serie, tilstand, spillernavn, klubb, sesonger, kamper, fgPercent, ftPercent, poengsnitt);
                break;
            case "baseball":
                int homeruns = Integer.parseInt(scanner.nextLine().trim());
                System.out.println("Parsed Baseballkort: " + id + ", " + serie + ", " + tilstand + ", " + spillernavn + ", " + klubb + ", " + sesonger + ", " + kamper + ", " + homeruns);
                dbHandler.insertBaseballkort(id, serie, tilstand, spillernavn, klubb, sesonger, kamper, homeruns);
                break;

        }
    }
}