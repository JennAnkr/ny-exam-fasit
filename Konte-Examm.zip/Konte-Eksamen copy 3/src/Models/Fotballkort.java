package Models;

// Definerer klassen "Fotballkort" som arver fra "Kort"
public class Fotballkort extends Kort{

    int seriescoring;
    int cupscoring;

    // Konstruktør som initialiserer egenskapene til et fotballkort og kaller superklassens konstruktør
    public Fotballkort(int id, int serie, String tilstand, String spillernavn, String klubb, int sesonger, int kamper, int seriescoring, int cupscoring) {
        super(id, serie, tilstand, spillernavn, klubb, sesonger, kamper);
        this.seriescoring = seriescoring;
        this.cupscoring = cupscoring;
    }

    public int getSeriescoring() {
        return seriescoring;
    }

    public void setSeriescoring(int seriescoring) {
        this.seriescoring = seriescoring;
    }

    public int getCupscoring() {
        return cupscoring;
    }

    public void setCupscoring(int cupscoring) {
        this.cupscoring = cupscoring;
    }

}
