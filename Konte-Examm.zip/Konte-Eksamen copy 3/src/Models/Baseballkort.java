package Models;

public class Baseballkort extends Kort{

    int homerun;

    public Baseballkort(int id, int serie, String tilstand, String spillernavn, String klubb, int sesonger, int kamper, int homerun) {
        super(id, serie, tilstand, spillernavn, klubb, sesonger, kamper);
        this.homerun = homerun;
    }

    public int getHomerun() {
        return homerun;
    }

    public void setHomerun(int homerun) {
        this.homerun = homerun;
    }
}
