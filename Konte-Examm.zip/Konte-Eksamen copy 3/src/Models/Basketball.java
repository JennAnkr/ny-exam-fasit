package Models;

public class Basketball extends Kort{

    int fgpercent;
    int ftpercent;
    double poengsnitt;

    public Basketball(int id, int serie, String tilstand, String spillernavn, String klubb, int sesonger, int kamper, int fgpercent, int ftpercent, double poengsnitt) {
        super(id, serie, tilstand, spillernavn, klubb, sesonger, kamper);
        this.fgpercent = fgpercent;
        this.ftpercent = ftpercent;
        this.poengsnitt = poengsnitt;
    }

    public int getFgpercent() {
        return fgpercent;
    }

    public void setFgpercent(int fgpercent) {
        this.fgpercent = fgpercent;
    }

    public int getFtpercent() {
        return ftpercent;
    }

    public void setFtpercent(int ftpercent) {
        this.ftpercent = ftpercent;
    }

    public double getPoengsnitt() {
        return poengsnitt;
    }

    public void setPoengsnitt(double poengsnitt) {
        this.poengsnitt = poengsnitt;
    }

}
