package Models;

// Definerer klassen "Kort" som representerer et samlekort med ulike egenskaper
public class Kort {
    int id;
    int serie;

    String tilstand;
    String spillernavn;
    String klubb;
    int sesonger;
    int kamper;

    // Konstroktør som initialiserer alle egenskapene til kortet
    public Kort(int id, int serie, String tilstand, String spillernavn, String klubb, int sesonger, int kamper) {
        this.id = id;
        this.serie = serie;
        this.tilstand = tilstand;
        this.spillernavn = spillernavn;
        this.klubb = klubb;
        this.sesonger = sesonger;
        this.kamper = kamper;
    }
    // Getter- og setter-metoder for alle egenskapene
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getSerie() {
        return serie;
    }

    public void setSerie(int serie) {
        this.serie = serie;
    }

    public String getTilstand() {
        return tilstand;
    }

    public void setTilstand(String tilstand) {
        this.tilstand = tilstand;
    }

    public String getSpillernavn() {
        return spillernavn;
    }

    public void setSpillernavn(String spillernavn) {
        this.spillernavn = spillernavn;
    }

    public String getKlubb() {
        return klubb;
    }

    public void setKlubb(String klubb) {
        this.klubb = klubb;
    }

    public int getSesonger() {
        return sesonger;
    }

    public void setSesonger(int sesonger) {
        this.sesonger = sesonger;
    }

    public int getKamper() {
        return kamper;
    }

    public void setKamper(int kamper) {
        this.kamper = kamper;
    }

}
