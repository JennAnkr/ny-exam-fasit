import java.sql.SQLException;

// Definerer et grensesnitt for databasehåndtering
public interface IDataBaseHandler {

    // Metoder for å sette inn en ny samlerkortserie
    void insertSamlerkortSerie(int id,String utgiver, int utgitt, String sport, int antall);

    // Metode for å sette inn et nytt fotballkort
    void insertFotballkort(int id, int serie, String tilstand, String spillernavn, String klubb, int sesonger, int kamper, int seriescoringer, int cupscoringer) throws SQLException;

    // Metode for å sette inn et nytt basketballkort
    void insertBasketballkort(int id, int serie, String tilstand, String spillernavn, String klubb, int sesonger, int kamper, int fgPercent, int ftPercent, double poengsnitt);

    // Metode for å sette inn et nytt baseballkort
    void insertBaseballkort(int id, int serie, String tilstand, String spillernavn, String klubb, int sesonger, int kamper, int homeruns);

    // Metode for å hente alle samlerkort for en bestemt sport
    String getAllKortBySport(String sport);

    // Metode for å hente total antall registrerte samlerkort
    int getTotalKortCount();

    // Metode for å hente alle samlerkort i mint condition
    String getKortInMintCondition();

    int getAllRegistratedCards();

    String getAllMintConditionCards();
}
