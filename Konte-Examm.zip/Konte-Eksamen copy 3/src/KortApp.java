import javax.swing.*;
import java.awt.*;

public class KortApp {
    private final JFrame mainFrame; // Hovedvinduet i applikasjonen
    private final JTextArea displayArea; // Område for å vise tekst
    private final IDataBaseHandler databasehandler; // Håndterer databaseoperasjoner

    public KortApp() {
        // Setter opp hovedvinduet
        mainFrame = new JFrame("Samlekort Database");
        mainFrame.setSize(500, 400);
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        databasehandler = new Databasehandler(); // Initialiserer databasehandler

        // Oppretter menylinjen og menyen
        JMenuBar menuBar = new JMenuBar();
        JMenu menu = new JMenu("Alternativer");
        menuBar.add(menu);

        // Oppretter menyvalg
        JMenuItem viewAllCardsBySport = new JMenuItem("Se informasjon om alle samlerkort for en sport");
        JMenuItem viewTotalCardsRegistred = new JMenuItem("Se antall samlerkort registrert");
        JMenuItem viewMintConditionCards = new JMenuItem("Se informasjon om alle samlerkort som er i mint condition");
        JMenuItem exitApp = new JMenuItem("Avslutt programmet");

        // Legger til menyvalg i menyen
        menu.add(viewAllCardsBySport);
        menu.add(viewTotalCardsRegistred);
        menu.add(viewMintConditionCards);
        menu.addSeparator();
        menu.add(exitApp);

        mainFrame.setJMenuBar(menuBar); // Setter menylinjen til hovedvinduet

        // Oppretter tekstområde for å vise informasjon
        displayArea = new JTextArea();
        displayArea.setEditable(false); // Gjør tekstområdet skrivebeskyttet
        mainFrame.add(new JScrollPane(displayArea), BorderLayout.CENTER); // Legger til tekstområdet i hovedvinduet

        // Legger til handlinger for menyvalgene
        viewAllCardsBySport.addActionListener(e -> showAllCardsBySport());
        viewTotalCardsRegistred.addActionListener(e -> showTotalCardCount());
        viewMintConditionCards.addActionListener(e -> showMintConditionCards());
        exitApp.addActionListener(e -> System.exit(0)); // Avslutter programmet

        mainFrame.setVisible(true); // Gjør hovedvinduet synlig
    }

    // Viser alle samlerkort i mint condition
    private void showMintConditionCards() {
        String kort = databasehandler.getAllMintConditionCards();
        displayArea.setText("Samlerkort i mint condition:\n\n" + kort);
    }

    // Viser totalt antall registrerte samlerkort
    private void showTotalCardCount() {
        int kort = databasehandler.getAllRegistratedCards();
        displayArea.setText("Antall samlerkort registrert: " + kort);
    }

    // Viser alle samlerkort for en bestemt sport
    private void showAllCardsBySport() {
        String sport = JOptionPane.showInputDialog(mainFrame, "Angi sport:");
        if (sport != null && !sport.isEmpty() && (sport.equalsIgnoreCase("Baseball") || sport.equalsIgnoreCase("Fotball") || sport.equalsIgnoreCase("Basketball"))) {
            String kort = databasehandler.getAllKortBySport(sport); // Henter samlerkort for valgt sport
            displayArea.setText("Samlerkort for sport " + sport + ":\n\n" + kort);
        } else {
            // Viser feilmelding hvis sport er ugyldig
            JOptionPane.showMessageDialog(mainFrame, "Ugyldig sport", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Hovedmetode for å starte programmet
    public static void main(String[] args) {
        SwingUtilities.invokeLater(KortApp::new);
    }
}
