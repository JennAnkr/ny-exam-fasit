
import java.sql.*;
public class Databasehandler implements IDataBaseHandler {

// Database URL, brrukernavn og passord
    private static final String DATABASE_URL = "jdbc:mysql://localhost:3306/Kort";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "Sofa2097";

    // Metode for å koble opp databasen
    private Connection connect() throws SQLException {
        return DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);
    }

    // Metode for å sette inn en ny samlekort serie
    @Override
    public void insertSamlerkortSerie(int id, String utgiver, int utgitt, String sport, int antall) {
        String sql = "INSERT INTO SamlerkortSerie(Id,Utgiver, Utgitt, Sport, Antall) VALUES (?,?,?,?,?)";
        try (Connection conn = this.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.setString(2,utgiver);
            pstmt.setInt(3, utgitt);
            pstmt.setString(4, sport);
            pstmt.setInt(5,antall);
            pstmt.executeUpdate();
            System.out.println("Inserted samlerkort serie with id:" + id);
        } catch (SQLException e) {
            e.printStackTrace();
        }


    }
    // Metode for å samle inn et nytt fotballkort
    @Override
    public void insertFotballkort(int id, int serie, String tilstand, String spillernavn, String klubb, int sesonger, int kamper, int seriescoringer, int cupscoringer) throws SQLException {
        String sql = "INSERT INTO Fotballkort(Id, Serie, Tilstand, Spillernavn, Klubb, Sesonger, Kamper, Seriescoringer, Cupscoringer) VALUES(?,?,?,?,?,?,?,?,?)";
        try (Connection conn = this.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.setInt(2, serie);
            pstmt.setString(3, tilstand);
            pstmt.setString(4, spillernavn);
            pstmt.setString(5,klubb);
            pstmt.setInt(6, sesonger);
            pstmt.setInt(7, kamper);
            pstmt.setInt(8, seriescoringer);
            pstmt.setInt(9, cupscoringer);
            pstmt.executeUpdate();
            System.out.println("Inserted fotballkort with id:" + id);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    // Metode for å sette inn nytt basketballkort
    @Override
    public void insertBasketballkort(int id, int serie, String tilstand, String spillernavn, String klubb, int sesonger, int kamper, int fgPercent, int ftPercent, double poengsnitt) {
        String sql = "INSERT INTO Basketballkort(Id, Serie, Tilstand, Spillernavn, Klubb, Sesonger, Kamper, FGPercent, FTPercent, Poengsnitt) VALUES(?,?,?,?,?,?,?,?,?,?)";
        try (Connection conn = this.connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.setInt(2, serie);
            pstmt.setString(3, tilstand);
            pstmt.setString(4, spillernavn);
            pstmt.setString(5, klubb);
            pstmt.setInt(6, sesonger);
            pstmt.setInt(7, kamper);
            pstmt.setInt(8, fgPercent);
            pstmt.setInt(9, ftPercent);
            pstmt.setDouble(10, poengsnitt);
            pstmt.executeUpdate();
            System.out.println("Inserted basketballkort with id: " + id);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    //Metode for å sette inn et nytt baseballkort
    @Override
    public void insertBaseballkort(int id, int serie, String tilstand, String spillernavn, String klubb, int sesonger, int kamper, int homeruns) {
            String sql = "INSERT INTO Baseballkort(Id, Serie, Tilstand, Spillernavn, Klubb, Sesonger, Kamper, Homeruns) VALUES(?,?,?,?,?,?,?,?)";
            try (Connection conn = this.connect();
                 PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, id);
                pstmt.setInt(2, serie);
                pstmt.setString(3, tilstand);
                pstmt.setString(4, spillernavn);
                pstmt.setString(5, klubb);
                pstmt.setInt(6, sesonger);
                pstmt.setInt(7, kamper);
                pstmt.setInt(8,homeruns);
                pstmt.executeUpdate();
                System.out.println("Inserted baseballkort with id: " + id);
            } catch (SQLException e) {
                e.printStackTrace();
            }
    }
    // Metode for å hente alle samlekortserier for en bestemt sport
    @Override
    public String getAllKortBySport(String sport) {
        StringBuilder result = new StringBuilder();
        try (Connection conn = this.connect()) {
            Statement stmt = conn.createStatement();
            ResultSet rs = null;
            switch (sport.toLowerCase()) {
                case "fotball":
                    rs = stmt.executeQuery("SELECT * FROM Fotballkort WHERE Serie in (SELECT id FROM SamlerkortSerie WHERE UPPER(Sport) = UPPER('"+sport+"') )");
                    while (rs.next()) {
                        result.append("ID:").append(rs.getInt("id"))
                                .append(", Serie: ").append(rs.getInt("Serie"))
                                .append(", Tilstand: ").append(rs.getString("Tilstand"))
                                .append(", Spillernavn: ").append(rs.getString("Spillernavn"))
                                .append(", Klubb: ").append(rs.getString("Klubb"))
                                .append(", Sesonger: ").append(rs.getInt("Sesonger"))
                                .append(", Kamper: ").append(rs.getInt("Kamper"))
                                .append(", Seriescoringer: ").append(rs.getInt("Seriescoringer"))
                                .append(", Cupscoringer: ").append(rs.getInt("Cupscoringer")).append("\n");
                    }
                    break;
                case "basketball":
                    rs = stmt.executeQuery("SELECT * FROM Basketballkort WHERE Serie in (SELECT id FROM SamlerkortSerie WHERE UPPER(Sport) = UPPER('"+sport+"') )");
                    while (rs.next()) {
                        result.append("ID:").append(rs.getInt("id"))
                                .append(", Serie: ").append(rs.getInt("Serie"))
                                .append(", Tilstand: ").append(rs.getString("Tilstand"))
                                .append(", Spillernavn: ").append(rs.getString("Spillernavn"))
                                .append(", Klubb: ").append(rs.getString("Klubb"))
                                .append(", Sesonger: ").append(rs.getInt("Sesonger"))
                                .append(", Kamper: ").append(rs.getInt("Kamper"))
                                .append(", FGPercent: ").append(rs.getInt("FGPercent"))
                                .append(", FTPercent: ").append(rs.getInt("FTPercent"))
                                .append(", Poengsnitt: ").append(rs.getDouble("Poengsnitt")).append("\n");
                    }
                    break;
                case "baseball":
                    rs = stmt.executeQuery("SELECT * FROM Baseballkort WHERE Serie in (SELECT id FROM SamlerkortSerie WHERE UPPER(Sport) = UPPER('"+sport+"') )");
                    while (rs.next()) {
                        result.append("ID:").append(rs.getInt("id"))
                                .append(", Serie: ").append(rs.getInt("Serie"))
                                .append(", Tilstand: ").append(rs.getString("Tilstand"))
                                .append(", Spillernavn: ").append(rs.getString("Spillernavn"))
                                .append(", Klubb: ").append(rs.getString("Klubb"))
                                .append(", Sesonger: ").append(rs.getInt("Sesonger"))
                                .append(", Kamper: ").append(rs.getInt("Kamper"))
                                .append(", Homeruns: ").append(rs.getInt("Homeruns")).append("\n");
                    }
                    break;
                default:
                    result.append("Ukjent sport:").append(sport).append("\n");
            }
        }catch (SQLException e) {
            e.printStackTrace();
        }
        return result.toString();
    }
    //Metode for å få informasjon om antall registrerte samlerkort
    @Override
    public int getTotalKortCount() {
        int result = 0;
        try (Connection conn = this.connect()) {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM Fotballkort UNION ALL SELECT COUNT(*) FROM Basketballkort UNION ALL SELECT COUNT(*) FROM Baseballkort");
            while (rs.next()) {
                result += rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return result;
    }
    // Metode for hente kort "mint condition"
    @Override
    public String getKortInMintCondition() {
        StringBuilder result = new StringBuilder();
        try (Connection conn = this.connect()) {
            Statement stmt = conn.createStatement();
            ResultSet rs1 = stmt.executeQuery("SELECT * FROM Fotballkort WHERE Tilstand = 'mint'");
            while (rs1.next()) {
                result.append("Fotballkort - ID: ").append(rs1.getInt("id"))
                        .append(", Serie: ").append(rs1.getInt("Serie"))
                        .append(", Spillernavn: ").append(rs1.getString("Spillernavn"))
                        .append(", Tilstand: ").append(rs1.getString("Tilstand")).append("\n");
            }
            ResultSet rs2 = stmt.executeQuery("SELECT * FROM Basketballkort WHERE Tilstand = 'mint'");
            while (rs2.next()) {
                result.append("Basketballkort - ID: ").append(rs2.getInt("id"))
                        .append(", Serie: ").append(rs2.getInt("Serie"))
                        .append(", Spillernavn: ").append(rs2.getString("Spillernavn"))
                        .append(", Tilstand: ").append(rs2.getString("Tilstand")).append("\n");
            }
            ResultSet rs3 = stmt.executeQuery("SELECT * FROM Baseballkort WHERE Tilstand = 'mint'");
            while (rs3.next()) {
                result.append("Baseballkort - ID: ").append(rs3.getInt("id"))
                        .append(", Serie: ").append(rs3.getInt("Serie"))
                        .append(", Spillernavn: ").append(rs3.getString("Spillernavn"))
                        .append(", Tilstand: ").append(rs3.getString("Tilstand")).append("\n");
            }
        }catch (SQLException e) {
            e.printStackTrace();
        }
        return result.toString();
    }

    @Override
    public int getAllRegistratedCards() {
        return getTotalKortCount();
    }

    @Override
    public String getAllMintConditionCards() {
        return getKortInMintCondition();
    }
}

